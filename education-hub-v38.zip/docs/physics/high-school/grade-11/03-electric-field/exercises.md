---
title: "Bài tập Chương 3 — Điện trường"
description: "Bài tập từ điện tích, Coulomb đến điện trường, điện thế, chuyển động điện tích và tụ điện."
order: 9
difficulty: "foundation-advanced"
tags:
  - physics
  - grade-11
  - electric-field
  - exercises
---

# Bài tập Chương 3 — Điện trường

> Đây là cách phân loại phục vụ mục đích sư phạm, không phải phân loại học thuật chính thức.

## Mức 1 — Điện tích và Coulomb

### Câu 1
Một vật có điện tích $-4,806\times10^{-19}\,\mathrm C$. Vật thừa hay thiếu bao nhiêu electron?

### Câu 2
Hai quả cầu dẫn giống nhau có $q_1=8\,\mu\,\mathrm C$, $q_2=-2\,\mu\,\mathrm C$. Cho tiếp xúc rồi tách. Tìm điện tích mỗi quả.

### Câu 3
Hai điện tích điểm $2\,\mu\,\mathrm C$ và $-5\,\mu\,\mathrm C$ cách nhau $20\,\mathrm{cm}$ trong chân không. Tính lực tương tác và cho biết hút hay đẩy.

### Câu 4
Giữ điện tích không đổi, khoảng cách tăng 3 lần. Lực Coulomb thay đổi thế nào?

### Câu 5
Hai điện tích trong điện môi $\varepsilon_r=4$ có lực F. Đưa hệ sang chân không, giữ q và r. Lực mới bằng bao nhiêu?

## Mức 2 — Điện trường

### Câu 6
Điện tích $Q=+3\,\mu\,\mathrm C$. Tính E tại điểm cách Q $30\,\mathrm{cm}$ trong chân không và nêu hướng.

### Câu 7
Tại một điểm $E=2\times10^4\,\mathrm{N/C}$. Điện tích $q=-5$ nC đặt tại đó chịu lực độ lớn bao nhiêu và hướng thế nào so với E?

### Câu 8
Hai điện tích $+Q$ và $+4Q$ cách nhau a. Tìm điểm E=0 trên đoạn nối chúng.

### Câu 9
Hai điện tích $+Q$ và $-4Q$ cách nhau a. Điểm E=0 nằm ở miền nào: giữa hai điện tích, phía ngoài gần +Q, hay phía ngoài gần -4Q? Giải thích trước khi tính.

### Câu 10
Tại M có hai vectơ điện trường vuông góc, độ lớn $3\times10^4$ và $4\times10^4\,\mathrm{N/C}$. Tính E tổng.

### Câu 11
Một hạt q dương, m=2 g đứng cân bằng trong điện trường đều thẳng đứng. Lấy g=$10\,\mathrm{m/s^2}$, $q=2\,\mu\mathrm C$. Tìm độ lớn và hướng E.

## Mức 3 — Công, điện thế

### Câu 12
Điện tích $q=3\,\mu\,\mathrm C$ dịch chuyển $5\,\mathrm{cm}$ theo chiều E trong trường đều $E=2000\,\mathrm{V/m}$. Tính công lực điện.

### Câu 13
$V_M=120\,\mathrm V$, $V_N=50\,\mathrm V$. Tính $U_{MN}$ và công lực điện khi chuyển $q=-2\,\mu\,\mathrm C$ từ M đến N.

### Câu 14
Điện tích điểm $Q=+4\,\mu\,\mathrm C$. Chọn V=0 ở vô cực. Tính V tại $r=20\,\mathrm{cm}$.

### Câu 15
Hai điện tích $+Q$ và $-Q$. Điểm M cách hai điện tích bằng nhau. Có thể kết luận E=0 tại M không? Có thể kết luận V=0 không?

### Câu 16
Điện trường đều $E=500\,\mathrm{V/m}$. Hai điểm A,B cách nhau $20\,\mathrm{cm}$ theo phương E, B nằm theo chiều E từ A. Tính $V_A-V_B$.

## Mức 3 — Tụ điện

### Câu 17
Tụ $C=4\,\mu\,\mathrm F$ đặt dưới $U=25\,\mathrm V$. Tính Q và W.

### Câu 18
Tụ phẳng có diện tích bản S, khoảng cách d. Tăng S gấp 2 và d gấp 3, điện môi không đổi. C thay đổi bao nhiêu lần?

### Câu 19
Tụ đang nối nguồn U không đổi. Đưa điện môi $\varepsilon_r=5$ lấp đầy. Q và W thay đổi thế nào?

### Câu 20
Tụ đã nạp rồi ngắt nguồn. Đưa cùng điện môi $\varepsilon_r=5$ lấp đầy. U và W thay đổi thế nào?

### Câu 21
Hai tụ $C_1=3\,\mu\,\mathrm F$, $C_2=6\,\mu\,\mathrm F$ ghép nối tiếp vào $12\,\mathrm V$. Tính $C_{eq}$, Q của chuỗi và U trên mỗi tụ.

### Câu 22
Hai tụ trên ghép song song vào $12\,\mathrm V$. Tính $C_{eq}$ và tổng điện tích.

## Mức 4 — Chuyển động điện tích

### Câu 23
Proton ban đầu đứng yên trong E đều $10^4\,\mathrm{V/m}$. Viết biểu thức gia tốc theo $e,m_p$ và nêu hướng.

### Câu 24
Electron được tăng tốc từ nghỉ qua hiệu điện thế có độ lớn $200\,\mathrm V$. Viết biểu thức tốc độ theo $e,m_e$.

### Câu 25
Hạt q dương bay ngang với $v_0$ vào điện trường đều E hướng lên. Viết phương trình quỹ đạo với gốc tại điểm vào.

### Câu 26
Một hạt có $q/m=2\times10^7\,\mathrm{C/kg}$, bay ngang với $v_0=2\times10^5\,\mathrm{m/s}$ qua vùng $E=10^4\,\mathrm{V/m}$ dài $\ell=0,10\,\mathrm m$. Tính thời gian trong trường và độ lệch theo phương E.

## Mức 4–5 — Tụ nâng cao

### Câu 27
Tụ $C_1=2\,\mu\,\mathrm F$ nạp ở $12\,\mathrm V$; tụ $C_2=4\,\mu\,\mathrm F$ chưa tích điện. Ngắt $C_1$ khỏi nguồn rồi nối song song cùng cực với $C_2$. Tính điện áp cuối.

### Câu 28
Hai tụ $C_1=2\,\mu\,\mathrm F$, $C_2=8\,\mu\,\mathrm F$ nối tiếp. Tỉ số $U_1/U_2$ bằng bao nhiêu?

### Câu 29
Một tụ phẳng cô lập có Q không đổi. Tăng khoảng cách hai bản gấp 2. Cho rằng vẫn trong mô hình tụ phẳng. Tìm tỉ số $C'/C$, $U'/U$, $W'/W$.

### Câu 30
Một tụ phẳng vẫn nối nguồn lí tưởng. Tăng khoảng cách hai bản gấp 2. Tìm các tỉ số trên và thêm $Q'/Q$.

### Câu 31
Hai điện tích cùng dấu $q_1=Q$, $q_2=9Q$ cách nhau $40\,\mathrm{cm}$. Tìm vị trí điểm E=0.

### Câu 32
Hai điện tích trái dấu $q_1=Q$, $q_2=-4Q$ cách nhau a. Tìm vị trí điểm E=0 theo khoảng cách đến $q_1$.

### Câu 33
Ba điện tích dương bằng nhau Q đặt ở ba đỉnh tam giác đều cạnh a. Tính độ lớn điện trường tại tâm.

### Câu 34
Bỏ một trong ba điện tích ở Câu 33. Tính E tại tâm do hai điện tích còn lại theo E0, trong đó E0 là độ lớn trường do một điện tích tại tâm.

### Câu 35
Một tụ cô lập có điện dung C, điện tích Q. Nếu điện dung tăng 4 lần do thay cấu tạo, công cơ học/trao đổi năng lượng làm năng lượng điện trường giảm bao nhiêu phần trăm so với ban đầu?


## Mức 3–4 — Bổ sung cân bằng điện tích và con lắc điện

### Câu 36
Hai điện tích $+Q$ và $+4Q$ cách nhau $30\,\mathrm{cm}$. Tìm điểm trên đoạn nối hai điện tích nơi điện trường tổng bằng 0.

### Câu 37
Hai điện tích $+Q$ và $-9Q$ cách nhau $40\,\mathrm{cm}$. Xác định miền có thể chứa điểm $E=0$, rồi tìm khoảng cách từ điểm đó tới $+Q$.

### Câu 38
Quả cầu nhỏ khối lượng 10 g, điện tích $+2,0\,\mu\,\mathrm C$ treo bằng dây trong điện trường đều nằm ngang. Dây lệch 30° so với phương thẳng đứng. Lấy $g=10\,\mathrm{m/s^2}$. Tính E.

### Câu 39
Giữ hệ Câu 38 nhưng đổi điện tích thành âm với cùng độ lớn. Độ lệch của dây thay đổi thế nào nếu chỉ xét độ lớn? Chiều lệch thay đổi thế nào?

### Câu 40
Một hạt tích điện đứng cân bằng tự do trong điện trường đều thẳng đứng hướng lên. Cho $m=2,0\times10^{-6}\,\mathrm{kg}$, $q=+5,0\times10^{-9}\,\mathrm C$. Tính E, lấy $g=9,8\,\mathrm{m/s^2}$.

### Câu 41
Hai điện tích cùng dấu $q_1$ và $q_2$ có điểm E=0 nằm giữa chúng và cách $q_1$ một đoạn bằng 1/3 khoảng cách tới $q_2$. Tìm tỉ số $|q_1|/|q_2|$.

### Câu 42 — Điện trường hiệu dụng
Một con lắc đơn tích điện dương nằm trong điện trường đều thẳng đứng hướng xuống. Viết gia tốc hiệu dụng $g_{eff}$ theo g, q, E, m và nêu xu hướng chu kì nếu qE cùng chiều trọng lực.

## Kho luyện tập theo từng bài trong chương

Phần dưới đây **không sao chép lặp lại câu hỏi**. Nó gom các ngân hàng theo từng bài để người học có thể luyện hàng trăm câu trong chương mà vẫn biết mỗi câu thuộc kiến thức nào.

- **Bài 1 — Thuyết electron và bảo toàn điện tích** — 35 câu/bài: [Bài tập](practice/01-electron-theory-charge-conservation/exercises.md) · [Đáp án](practice/01-electron-theory-charge-conservation/solutions.md)
- **Bài 2 — Định luật Coulomb** — 51 câu/bài: [Bài tập](practice/02-coulomb-law/exercises.md) · [Đáp án](practice/02-coulomb-law/solutions.md)
- **Bài 3 — Điện trường và cường độ điện trường** — 91 câu/bài: [Bài tập](practice/03-electric-field-intensity/exercises.md) · [Đáp án](practice/03-electric-field-intensity/solutions.md)
- **Bài 4 — Tổng hợp điện trường và cân bằng điện tích** — 25 câu/bài: [Bài tập](practice/04-field-superposition-equilibrium/exercises.md) · [Đáp án](practice/04-field-superposition-equilibrium/solutions.md)
- **Bài 5 — Công của lực điện, điện thế và hiệu điện thế** — 98 câu/bài: [Bài tập](practice/05-work-potential-voltage/exercises.md) · [Đáp án](practice/05-work-potential-voltage/solutions.md)
- **Bài 6 — Tụ điện, điện dung và năng lượng** — 20 câu/bài: [Bài tập](practice/06-capacitors/exercises.md) · [Đáp án](practice/06-capacitors/solutions.md)
- **Bài 7 — Chuyển động của điện tích trong điện trường đều** — 76 câu/bài: [Bài tập](practice/07-charged-particle-motion/exercises.md) · [Đáp án](practice/07-charged-particle-motion/solutions.md)
- **Bài 8 — Ghép tụ và các bài toán tụ điện nâng cao** — 18 câu/bài: [Bài tập](practice/08-advanced-capacitors/exercises.md) · [Đáp án](practice/08-advanced-capacitors/solutions.md)
- **Bài 9 — Cân bằng điện tích và con lắc trong điện trường** — 37 câu/bài: [Bài tập](practice/09-electrostatic-equilibrium-charged-pendulum/exercises.md) · [Đáp án](practice/09-electrostatic-equilibrium-charged-pendulum/solutions.md)


---

[← Bài 9](09-electrostatic-equilibrium-charged-pendulum.md) | [↑ Chương](index.md) | [Lời giải →](solutions.md)

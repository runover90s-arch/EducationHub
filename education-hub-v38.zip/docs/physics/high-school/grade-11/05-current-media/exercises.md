---
title: "Bài tập Chương 5 — Dòng điện trong các môi trường"
description: "Bài tập phân hóa về kim loại, điện phân, chất khí, bán dẫn và chân không."
order: 6
difficulty: "foundation-advanced"
tags:
  - physics
  - grade-11
  - exercises
---

# Bài tập Chương 5 — Dòng điện trong các môi trường

> Đây là cách phân loại phục vụ mục đích sư phạm, không phải phân loại học thuật chính thức.

## Mức 1 — Nhận biết và nền tảng

**Câu 1.** Hạt tải điện chủ yếu trong kim loại là gì? Chiều chuyển động có hướng của chúng so với chiều dòng điện quy ước như thế nào?

**Câu 2.** Trong chất điện phân, những hạt nào tạo dòng điện?

**Câu 3.** Vì sao không khí ở điều kiện bình thường dẫn điện kém?

**Câu 4.** Trong bán dẫn loại n, hạt tải đa số là gì? Trong bán dẫn loại p thì sao?

**Câu 5.** Tia catot là chùm hạt gì?

**Câu 6.** Một dây kim loại có $R_0=20\,\Omega$ ở 20°C, $\alpha=4,0\times10^{-3}\,\text{K}^{-1}$. Tính R ở 120°C theo mô hình tuyến tính.

**Câu 7.** Cặp nhiệt điện có $\alpha_T=40\,\mu\text{V/K}$. Hai mối nối chênh nhau $200\,\mathrm K$. Tính suất điện động.

**Câu 8.** Dòng $2\,\mathrm A$ qua bình điện phân trong 10 phút. Tính điện lượng qua bình.

## Mức 2 — Thông hiểu

**Câu 9.** Dòng $0,80\,\mathrm A$ qua dung dịch Cu$^{2+}$ trong 30 phút. Lấy $A_{Cu}=64$ g/mol, $F=96500\,\mathrm{C/mol}$. Tính khối lượng đồng bám ở catot.

**Câu 10.** Hai bình điện phân Ag$^+$ và Cu$^{2+}$ mắc nối tiếp. Cùng điện lượng đi qua. So sánh khối lượng Ag và Cu giải phóng, với $A_{Ag}=108$, $A_{Cu}=64$.

**Câu 11.** Giải thích vì sao tăng nhiệt độ thường làm điện trở kim loại tăng nhưng có thể làm điện trở bán dẫn giảm.

**Câu 12.** Nêu sự khác nhau giữa ion hóa khí và phân li điện li trong dung dịch.

**Câu 13.** Vì sao diode bán dẫn có thể dùng để chỉnh lưu?

**Câu 14.** Dòng quang điện bão hòa là $8,0\,\mu\,\mathrm A$. Tính số electron đến anot trong $1\,\mathrm s$.

## Mức 3 — Vận dụng

**Câu 15.** Bóng đèn có điện trở $24\,\Omega$ ở 20°C. Khi sáng, điện trở $240\,\Omega$. Lấy $\alpha=4,5\times10^{-3}\,\text{K}^{-1}$. Ước lượng nhiệt độ dây tóc theo mô hình tuyến tính.

**Câu 16.** Một mối hàn cặp nhiệt điện ở 0°C, mối kia trong lò. Hệ số $50\,\mu\,\mathrm{V/K}$, vôn kế chỉ $60\,\mathrm{mV}$. Tính nhiệt độ lò theo mô hình tuyến tính.

**Câu 17.** Bình điện phân AgNO$_3$ có dòng $0,25\,\mathrm A$ chạy trong 40 phút. Tính khối lượng Ag bám, lấy $A=108$, n=1.

**Câu 18.** Hai bình Fe$^{3+}$ và Cu$^{2+}$ nối tiếp. Nếu 1,40 g Fe được giải phóng, tính khối lượng Cu tương ứng. Lấy Fe=56, Cu=64.

**Câu 19.** Một dòng quang điện bão hòa 16 µA. Chùm sáng đơn sắc $400\,\mathrm{nm}$ có công suất 20 µW. Lấy $h=6,626\times10^{-34}\,\mathrm{J\,s}$, $c=3,00\times10^8\,\mathrm{m/s}$. Tính hiệu suất đếm electron/photon theo mô hình đơn giản.

## Mức 4 — Vận dụng cao

**Câu 20.** Một bình điện phân có điện trở $6\,\Omega$ mắc nối tiếp điện trở $4\,\Omega$ với nguồn $\mathcal E=12\,\mathrm V$, $r=2\,\Omega$. Dung dịch Ag$^+$. Tính khối lượng Ag bám sau 32 phút 10 giây.

**Câu 21.** Một dây kim loại có điện trở $10\,\Omega$ ở 20°C. Khi mắc vào nguồn $12\,\mathrm V$, nhiệt độ tăng đến 220°C. Lấy $\alpha=4,0\times10^{-3}\,\mathrm K^{-1}$. Bỏ qua điện trở dây nối. Tính dòng cuối cùng và so với dòng ban đầu nếu giả sử nhiệt độ ban đầu đúng 20°C.

**Câu 22.** Một diode lí tưởng nối tiếp $R=1\,\mathrm{k}\Omega$ với nguồn $5\,\mathrm V$. Tính dòng khi diode phân cực thuận. Nếu đảo diode thì dòng bằng bao nhiêu trong mô hình lí tưởng?

**Câu 23.** Vì sao không thể mô tả tia lửa điện trong không khí bằng một điện trở R không đổi độc lập điện áp? Trả lời theo cơ chế hạt tải.

**Câu 24.** Một tế bào quang điện có hiệu suất đếm 2%. Chùm photon $500\,\mathrm{nm}$ có công suất 1 mW chiếu vào. Tính dòng bão hòa lí tưởng hóa nếu mọi electron phát ra đều được thu.

## Thử thách tư duy

**Câu 25.** So sánh bốn môi trường: kim loại, điện phân, khí, bán dẫn theo ba tiêu chí: hạt tải điện, cơ chế tạo hạt tải và tác động điển hình của nhiệt độ.

---

[↑ Chương](index.md) | [Lời giải →](solutions.md)

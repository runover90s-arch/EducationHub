#!/usr/bin/env python3
"""QA cho ngân hàng bài tập nhập từ các PDF Vật lí 11.

Mục tiêu:
- không thất lạc cặp đề/đáp án;
- không lặp source-id;
- không sao chép lặp lại cùng một câu vào nhiều bài học;
- mọi ảnh cần để giữ nguyên công thức/hình vẽ phải tồn tại;
- A/B/C/D và a/b/c/d phải tách paragraph, hình dữ kiện phải đứng trước lựa chọn/mệnh đề;
- câu Vận dụng cao phải có lời giải đủ dài hoặc ảnh lời giải;
- bảo vệ quy mô ngân hàng khỏi bị giảm ngoài ý muốn.

Checker này kiểm tra tính toàn vẹn xuất bản. Nó không thay thế việc thẩm định học thuật thủ công.
"""
from pathlib import Path
import re, sys, json, unicodedata, hashlib
from collections import Counter

from practice_bank_common import figure_after_choices, image_refs, infer_marker_kind, marker_layout_errors

ROOT=Path(__file__).resolve().parents[1]
GRADE=ROOT/'docs/physics/high-school/grade-11'
REPORT=ROOT/'tools/v9_import_report.json'
MIN_IMPORTED=1600
errors=[]; warnings=[]
source_seen={}; alias_seen={}; body_seen={}; imported=0; alias_count=0; image_q=0; solution_img=0
by_chapter=Counter(); by_level=Counter(); by_format=Counter(); files=0

def norm_text(s:str)->str:
    s=re.sub(r'<!--.*?-->',' ',s,flags=re.S)
    s=re.sub(r'!\[[^]]*\]\([^)]*\)(?:\{[^}]*\})?',' ',s)
    s=re.sub(r'[`*_#>]',' ',s)
    s=unicodedata.normalize('NFKC',s).lower()
    s=re.sub(r'\s+',' ',s).strip()
    return s

def split_imported(s:str,marker:str):
    return s.split(marker,1)[1] if marker in s else ''

for ex in sorted(GRADE.glob('0[1-4]-*/practice/*/exercises.md')):
    et=ex.read_text(encoding='utf-8')
    if re.search(r'^#### Bài PDF \d+', et, re.M):
        errors.append(f'Còn nhãn Bài PDF legacy: {ex.relative_to(ROOT)}')
    sol=ex.with_name('solutions.md')
    old_marker='## Ngân hàng bài tập PDF mở rộng'
    new_marker='## Ngân hàng bài tập mở rộng'
    if old_marker in et:
        marker=old_marker; inline_answers=False
    elif new_marker in et:
        marker=new_marker; inline_answers=True
    else:
        continue
    files+=1
    if not sol.exists():
        errors.append(f'Thiếu file lời giải: {sol.relative_to(ROOT)}')
        continue
    st=sol.read_text(encoding='utf-8')
    es=split_imported(et,marker)

    # Legacy pages keep a separate imported-solution bank. New-format pages keep
    # each answer immediately below the exercise inside a pymdownx.details block.
    if inline_answers:
        ss=''
    else:
        sol_marker='## Đáp án và lời giải — Ngân hàng PDF mở rộng'
        if sol_marker not in st:
            errors.append(f'Thiếu phần lời giải PDF: {sol.relative_to(ROOT)}')
            continue
        ss=split_imported(st,sol_marker)

    em=list(re.finditer(r'^#### Bài(?: PDF)? (\d+)\s*\n\n<!-- source-id: ([^>]+) -->\n\n',es,re.M))
    en=[int(m.group(1)) for m in em]
    if en:
        curated_part=et.split(marker,1)[0]
        curated_nums=[int(x) for x in re.findall(r'^### Bài (\d+)\b',curated_part,re.M)]
        expected_start=max(curated_nums,default=0)+1
        expected=list(range(expected_start,expected_start+len(en)))
        if en != expected:
            errors.append(f'Số bài nhập không nối tiếp phần biên soạn trước: {ex.relative_to(ROOT)} -> mong {expected_start}..{expected[-1]}, thực tế {en[0]}..{en[-1]}')
    else:
        errors.append(f'Không tìm thấy bài nhập: {ex.relative_to(ROOT)}')
        continue

    sm=[]
    if not inline_answers:
        sm=list(re.finditer(r'^#### Bài PDF (\d+)\s*$',ss,re.M))
        sn=[int(m.group(1)) for m in sm]
        if en != list(range(1,len(en)+1)):
            errors.append(f'Số Bài PDF legacy không liên tục từ 1: {ex.relative_to(ROOT)}')
        if sn != en:
            errors.append(f'Đề/lời giải PDF lệch số lượng: {ex.relative_to(ROOT)} -> đề {len(en)}, giải {len(sn)}')

    # group-level metadata for level/format
    headings=[]
    for m in re.finditer(r'^### (.+?) — (.+?)\s*$',es,re.M):
        headings.append((m.start(),m.group(1).strip(),m.group(2).strip()))

    # map separate solution blocks for legacy pages
    solblocks={}
    if not inline_answers:
        for i,m in enumerate(sm):
            end=sm[i+1].start() if i+1<len(sm) else len(ss)
            solblocks[int(m.group(1))]=ss[m.end():end]

    for i,m in enumerate(em):
        end=em[i+1].start() if i+1<len(em) else len(es)
        block=es[m.end():end]
        seq=int(m.group(1)); sid=m.group(2).strip(); imported+=1
        mm=re.match(r'BT-Chuong-(I|II|III|IV)-p\d+-q\d+-\d+$',sid)
        if not mm:
            errors.append(f'source-id sai định dạng: {sid}')
            ch='?'
        else:
            ch=mm.group(1); by_chapter[ch]+=1
        if sid in source_seen:
            errors.append(f'source-id lặp: {sid} ở {ex.relative_to(ROOT)} và {source_seen[sid]}')
        elif sid in alias_seen:
            errors.append(f'source-id canonical trùng với alias đã khai báo: {sid} (alias của {alias_seen[sid]})')
        else:
            source_seen[sid]=str(ex.relative_to(ROOT))

        # Source aliases preserve backward traceability for confirmed duplicate
        # occurrences that are intentionally not republished as separate exercises.
        aliases=[a.strip() for a in re.findall(r'<!-- source-alias-id: ([^>]+) -->',block)]
        for alias in aliases:
            alias_count += 1
            if not re.match(r'BT-Chuong-(I|II|III|IV)-p\d+-q\d+-\d+$',alias):
                errors.append(f'source-alias-id sai định dạng: {alias}')
                continue
            if alias == sid:
                errors.append(f'source-alias-id trùng canonical: {alias}')
            elif alias in source_seen:
                errors.append(f'source-alias-id đụng source-id canonical: {alias}')
            elif alias in alias_seen:
                errors.append(f'source-alias-id lặp: {alias} (canonical {sid} và {alias_seen[alias]})')
            else:
                alias_seen[alias]=sid

        # Determine active group heading before block.
        active=[h for h in headings if h[0] < m.start()]
        if active:
            level,fmt=active[-1][1],active[-1][2]
            by_level[level]+=1; by_format[fmt]+=1
        else:
            level=fmt='Không rõ'
            warnings.append(f'Không xác định nhóm mức độ: {ex.relative_to(ROOT)} Bài {seq}')

        # In inline-answer pages only the part before the details block is the question.
        question_block=block.split('??? success "Đáp án và lời giải"',1)[0] if inline_answers else block
        if re.search(r'(?m)^(?:Đáp án|Hướng dẫn(?: giải)?|Lời giải)\s*:?[ \t]*$', question_block):
            errors.append(f'Đáp án/hướng dẫn bị lẫn vào phần đề: {ex.relative_to(ROOT)} Bài {seq}')
        if 'source-faithful/' in question_block:
            errors.append(f'Còn ảnh chụp legacy source-faithful: {ex.relative_to(ROOT)} Bài {seq}')

        # Deterministic option/statement layout for imported source blocks.
        # Infer from visible markers rather than group headings: historical PDF
        # groups can contain mixed formats, so headings are not authoritative.
        kind = infer_marker_kind(question_block)
        if kind:
            for issue in marker_layout_errors(question_block, kind):
                errors.append(f'Layout {kind} không hợp lệ: {ex.relative_to(ROOT)} Bài {seq}: {issue}')
            if figure_after_choices(question_block, kind):
                errors.append(
                    f'Hình nằm sau phương án/mệnh đề: {ex.relative_to(ROOT)} Bài {seq}; '
                    'thứ tự phải là đề dẫn -> hình -> lựa chọn/mệnh đề'
                )
        nb=norm_text(question_block)
        # Duplicate-detection eligibility must not change merely because presentation
        # normalization moves SI units into LaTeX (e.g. `$5$ cm` -> `$5\,\mathrm{cm}$`).
        semantic_len_text=re.sub(r'\\mathrm\{([^{}]*)\}', r'\1', nb)
        semantic_len_text=semantic_len_text.replace(r'\,', ' ')
        semantic_len_text=re.sub(r'\\(?:text|operatorname)\{([^{}]*)\}', r'\1', semantic_len_text)
        if len(semantic_len_text)>150 and 'công thức/kí hiệu của câu này được giữ nguyên bằng ảnh' not in nb:
            key=hashlib.sha1(nb.encode()).hexdigest()
            if key in body_seen:
                errors.append(f'Câu nhập trùng nguyên văn: {ex.relative_to(ROOT)} Bài {seq} và {body_seen[key]}')
            else:
                body_seen[key]=f'{ex.relative_to(ROOT)} Bài {seq}'

        # Image references must resolve relative to the Markdown file. Keep this
        # source-bank check even though check_site.py also audits images globally.
        for ref in image_refs(question_block):
            if ref.startswith(('http://', 'https://', 'data:')):
                continue
            target=(ex.parent/ref.split('#',1)[0].split('?',1)[0]).resolve()
            if not target.exists():
                errors.append(f'Ảnh bài tập không tồn tại: {ex.relative_to(ROOT)} -> {ref}')
            else:
                image_q+=1

        if inline_answers:
            dm=re.search(r'\?\?\? success "Đáp án và lời giải"\s*\n(.*)',block,re.S)
            if not dm:
                errors.append(f'Thiếu nút đáp án/lời giải: {ex.relative_to(ROOT)} Bài {seq}')
                sb=''
            else:
                sb=dm.group(1)
        else:
            sb=solblocks.get(seq,'')
            for ref in image_refs(sb):
                if ref.startswith(('http://', 'https://', 'data:')):
                    continue
                target=(sol.parent/ref.split('#',1)[0].split('?',1)[0]).resolve()
                if not target.exists():
                    errors.append(f'Ảnh lời giải không tồn tại: {sol.relative_to(ROOT)} -> {ref}')
                else:
                    solution_img+=1

        # Vận dụng cao must have an actual explanation.
        if level.startswith('Vận dụng cao'):
            plain=re.sub(r'\*\*Đáp án:\*\*[^\n]*','',sb)
            plain=norm_text(plain)
            if len(plain)<80 and 'source-faithful/' not in sb:
                errors.append(f'Vận dụng cao thiếu lời giải chi tiết: {ex.relative_to(ROOT)} Bài {seq}')

if imported < MIN_IMPORTED:
    errors.append(f'Ngân hàng PDF chỉ còn {imported} câu, thấp hơn ngưỡng bảo vệ {MIN_IMPORTED}.')

# Dạng bài: không cho phép lặp nguyên tên trong cùng bài học.
type_count=0
for lesson in sorted(GRADE.glob('0[1-4]-*/[0-9][0-9]-*.md')):
    txt=lesson.read_text(encoding='utf-8')
    heads=re.findall(r'^###\s+Dạng\s+\d+\s*[—:-]\s*(.+?)\s*$',txt,re.M|re.I)
    type_count += len(heads)
    seen={}
    for h in heads:
        key=unicodedata.normalize('NFKC',h).casefold()
        key=re.sub(r'\s+',' ',key).strip()
        if key in seen:
            errors.append(f'Dạng bài trùng tên trong {lesson.relative_to(ROOT)}: {h!r}')
        else:
            seen[key]=1

if REPORT.exists():
    try:
        rep=json.loads(REPORT.read_text(encoding='utf-8'))
        expected=int(rep.get('deduplicated_verified_imported',-1))
        if expected != imported:
            errors.append(f'Report ghi {expected} câu nhưng repository thực tế có {imported}.')

        # Exact alias mapping is part of provenance integrity, not an exemption
        # from duplicate detection. Alias IDs must disappear from learner-facing
        # canonical blocks while remaining traceable to one canonical source ID.
        rep_aliases=rep.get('source_aliases_preserved',[])
        expected_aliases={(x.get('alias_source_id'),x.get('canonical_source_id')) for x in rep_aliases}
        actual_aliases={(a,c) for a,c in alias_seen.items()}
        if expected_aliases != actual_aliases:
            errors.append(f'Alias source-id lệch report: report={sorted(expected_aliases)}, repo={sorted(actual_aliases)}')
        traced=int(rep.get('source_records_traced', imported+alias_count))
        if traced != imported + alias_count:
            errors.append(f'Report ghi {traced} source record được truy vết nhưng canonical+alias thực tế là {imported+alias_count}.')

        # Verified fused-block migrations must name source IDs that actually exist.
        for mig in rep.get('source_id_migrations',[]):
            if mig.get('type') != 'split_fused_source_block':
                errors.append(f'Loại source-id migration không hỗ trợ: {mig.get("type")!r}')
                continue
            legacy=mig.get('legacy_source_id')
            children=mig.get('split_source_ids',[])
            if not legacy or legacy not in children:
                errors.append(f'Migration split thiếu legacy trong split_source_ids: {mig}')
            if len(children)<2 or len(set(children))!=len(children):
                errors.append(f'Migration split phải có ít nhất 2 source-id khác nhau: {mig}')
            for child in children:
                if child not in source_seen:
                    errors.append(f'Migration split tham chiếu source-id không tồn tại: {child}')
    except Exception as e:
        errors.append(f'Không đọc được {REPORT.relative_to(ROOT)}: {e}')
else:
    errors.append('Thiếu tools/v9_import_report.json')

CROSS=ROOT/'tools/v9_answer_crosscheck.json'
if CROSS.exists():
    try:
        cross=json.loads(CROSS.read_text(encoding='utf-8'))
        conflicts=cross.get('conflicts',[])
        if conflicts:
            errors.append(f'Cross-check đáp án nguồn còn {len(conflicts)} xung đột.')
    except Exception as e:
        errors.append(f'Không đọc được {CROSS.relative_to(ROOT)}: {e}')
else:
    errors.append('Thiếu tools/v9_answer_crosscheck.json')

print(f'[pdf-bank] {files} bài học có ngân hàng PDF; {imported} câu/bài canonical đã nhập; {alias_count} source alias được bảo toàn.')
print('[pdf-bank] Theo chương:', ', '.join(f'{k}={v}' for k,v in sorted(by_chapter.items())))
print('[pdf-bank] Theo mức độ:', ', '.join(f'{k}={v}' for k,v in by_level.items()))
print(f'[pdf-bank] {image_q} hình/đồ thị bài tập được tham chiếu; {solution_img} lời giải legacy dùng ảnh.')
print(f'[pdf-bank] {type_count} mục dạng bài ở 4 chương lõi; không lặp tên trong cùng bài học.')
if warnings:
    for w in warnings[:20]: print('WARN PDFBANK:',w)
    if len(warnings)>20: print(f'WARN PDFBANK: ... còn {len(warnings)-20} cảnh báo')
if errors:
    for e in errors: print('ERROR PDFBANK001:',e)
    print(f'[pdf-bank] {len(errors)} lỗi.')
    raise SystemExit(1)
print('[pdf-bank] 0 lỗi toàn vẹn. OK.')
